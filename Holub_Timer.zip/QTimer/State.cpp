#include <QString>
/**
 * @brief The State enum
 */
enum class State {
    RUNNING,
    PAUSED,
    STOPED,
};


